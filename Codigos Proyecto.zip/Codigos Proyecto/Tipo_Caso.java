package Tipo_Caso;

public class Tipo_Caso {
    private String Caso_Cybercrimen;
    private String Caso_Homicidio;
    private String Caso_Narcotico;

    public Tipo_Caso() {
        this.Caso_Cybercrimen = Caso_Cybercrimen;
        this.Caso_Homicidio = Caso_Homicidio;
        this.Caso_Narcotico = Caso_Narcotico;
    }

    public String getCaso_Cybercrimen() {
        return Caso_Cybercrimen;
    }

    public void setCaso_Cybercrimen(String Caso_Cybercrimen) {
        this.Caso_Cybercrimen = Caso_Cybercrimen;
    }

    public String getCaso_Homicidio() {
        return Caso_Homicidio;
    }

    public void setCaso_Homicidio(String Caso_Homicidio) {
        this.Caso_Homicidio = Caso_Homicidio;
    }

    public String getCaso_Narcotico() {
        return Caso_Narcotico;
    }

    public void setCaso_Narcotico(String Caso_Narcotico) {
        this.Caso_Narcotico = Caso_Narcotico;
    }
    public void Tipo_caso(){
        // Aqui escoje el tipo de caso
    }
}
