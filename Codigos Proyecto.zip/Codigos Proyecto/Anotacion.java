
package proyecto;


public class Anotacion {
    private String observaciones;
    private String fechaRegistro;

    public Anotacion(String observaciones, String fechaRegistro) {
        this.observaciones = observaciones;
        this.fechaRegistro = fechaRegistro;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
    
}
